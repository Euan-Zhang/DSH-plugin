# DSH 皮肤管理器（dsh-skin-manager）

给 DeepSeek Harness 的 Web 界面提供**皮肤管理**能力：内置皮肤 + 皮肤文件的导入/校验/安装，以及皮肤的选择切换与卸载。

## 功能

- 🎨 **内置皮肤**：默认皮肤（DSH 原生外观）、黑神话·悟空皮肤（黑金配色 + 毛玻璃金边 + 悟空官网视频底纹）。
- 🔁 **一键切换**：在「设置 → 皮肤」页点「使用」即可切换，立即生效、刷新后保持。
- ➕ **新增皮肤**：导入一个 `.dshskin` 皮肤文件（JSON）实现安装，安装后进入皮肤列表。
- ✅ **严格校验**：按《皮肤文件格式规范》逐字段校验，不合规的文件会被拒绝并给出中文原因。
- 🗑️ **卸载**：已导入的皮肤可一键卸载；内置皮肤不可卸载。

> 本质是一个 DSH **双面插件**：host 半部负责皮肤目录、校验、存储与 HTTP API；client 半部负责设置页 UI、主题令牌覆盖、样式与背景注入。不修改 DSH 源码。

---

## 目录结构

```text
dsh-skin-manager/
├─ package.json            # 包定义（dsh.client 声明）
├─ cordis.patch.yml        # host 登记（inject: webServer）
├─ lib/
│  ├─ index.js             # host 半部：皮肤目录/校验/存储/API/视频路由
│  └─ client.js            # client 半部：设置页 UI + 皮肤切换 + 背景/样式注入
├─ assets/
│  └─ wukong-video.mp4     # 黑神话·悟空皮肤的背景视频
├─ examples/
│  ├─ ocean-blue.dshskin   # 示例：深海蓝（深色 + 渐变背景）
│  ├─ rosy-light.dshskin   # 示例：玫瑰浅色（浅色 + 纯色背景）
│  ├─ wukong.dshskin       # 示例：黑神话·悟空（含 base64 视频背景，可导入）
│  └─ _gen-wukong.mjs      # 重新生成 wukong.dshskin 的脚本
├─ docs/
│  └─ 皮肤文件格式规范.md    # 可导入皮肤文件的格式与要求
├─ install.ps1             # Windows 一键安装
├─ install.sh              # macOS / Linux 一键安装
└─ README.md
```

---

## 安装

### Windows

1. 解压本目录（若拿到的是 zip）。
2. 右键 `install.ps1` → **使用 PowerShell 运行**（被拦截时先执行：`powershell -ExecutionPolicy Bypass -File .\install.ps1`）。
3. 脚本会：把插件复制到 `$DSH_HOME/profiles/node_modules/dsh-skin-manager/`，并在 `cordis.patch.yml` 里登记插件行。

### macOS / Linux

```bash
cd dsh-skin-manager
chmod +x install.sh
./install.sh
```

### 完成后

重启 `dsh web`，刷新浏览器（建议 Ctrl+Shift+R）。打开「设置 → 皮肤」即可看到皮肤列表。

> 若 web 服务不跑在默认 `web` profile 上，安装前先指定：Windows `$env:DSH_SKIN_PROFILE="你的profile名"`；macOS/Linux `DSH_SKIN_PROFILE=你的profile名 ./install.sh`。

### 手动安装（排障用）

1. 复制插件本体：
   ```bash
   cp -R dsh-skin-manager ~/.dsh/profiles/node_modules/dsh-skin-manager
   ```
2. 在 `~/.dsh/profiles/web/cordis.patch.yml` 加入：
   ```yaml
   - insert:
       - id: dsh-skin-manager
         name: dsh-skin-manager
         inject: [webServer]
   ```
   （若文件里是空数组 `[]`，把 `[]` 替换成上面这段。）
3. 重启 `dsh web`。

---

## 使用

1. 打开 **设置 → 皮肤**。
2. 皮肤列表每项显示名称、描述、作者与版本；当前生效的皮肤标「使用中」。
3. 点某张皮肤右侧的「使用」即切换。
4. 页面底部「新增皮肤」→「选择皮肤文件并安装」→ 选中一个 `.dshskin` 文件即完成安装。
5. 已导入的皮肤显示「卸载」按钮；内置皮肤不可卸载。

---

## 可导入皮肤文件格式

皮肤文件是一个 `.dshskin` JSON 文本，最小示例：

```json
{
  "schema": "dsh-skin",
  "schemaVersion": 1,
  "id": "my-skin",
  "name": "我的皮肤",
  "version": "1.0.0",
  "colorScheme": "dark",
  "tokens": { "--dsw-alias-brand-primary": "#4a9fd8" }
}
```

完整字段说明、`tokens`/`css`/`background` 的取值规则、以及**能否导入的判定清单**，见 [`docs/皮肤文件格式规范.md`](docs/皮肤文件格式规范.md)。

---

## 卸载

1. 删除插件目录：
   - Windows：`C:\Users\<你>\.dsh\profiles\node_modules\dsh-skin-manager`
   - macOS/Linux：`~/.dsh/profiles/node_modules/dsh-skin-manager`
2. 从 `~/.dsh/profiles/web/cordis.patch.yml` 里删掉 `dsh-skin-manager` 的 `insert` 条目。
3. 重启 `dsh web`。

> 已导入的皮肤数据保存在 `~/.dsh/profiles/skins/`；如需彻底清理可一并删除该目录。

---

## 注意事项

- **与旧皮肤插件冲突**：若此前装过 `dsh-skin-deepseek`、`dsh-skin-wukong` 等「常驻覆盖」式皮肤插件，它们会与皮肤管理器的切换叠加冲突。安装本插件后建议一并卸载它们。
- **视频背景也可导入**：用户导入的皮肤支持「颜色 / 渐变 / 图片 / 外部 URL / 视频」背景；视频用 `data:video/...` base64 内嵌（约 1MB 视频 ≈ 1.3MB JSON）或外部 URL 提供。
- **wukong 皮肤的文件版**：`examples/wukong.dshskin` 是黑神话皮肤的文件形态（含视频），可分享到未内置该皮肤的 DSH 实例并导入；本插件已内置 id=`wukong`，故同一环境再导入会因 id 冲突被拒（这正是校验规则之一）。
- **样式安全**：导入皮肤的 `css` 会被注入页面，为防注入已禁止 `@import`、`javascript:`、`expression(` 等危险片段；皮肤文件只影响外观，不具备执行脚本的能力。
